"""V0：diff 範圍檢查（SPEC §3.2.3、§3.3.1、§5.2.6.1、§6.1 V0）。純函式、無 I/O。

worker 端預檢與 coordinator 端跑的是**同一個函式**（§10.3.2 client/core 分離的意義）。
輸入是「改動了哪些路徑」——怎麼從 git bundle 算出這份清單是呼叫端的事。

檢查順序刻意固定（第一個失敗就是回報的理由）：
  1. base 必須等於 snapshot_ref（§3.1 不可變快照）
  2. changed ⊆ commitment.declared_paths（§5.2.6.1）——先比自己的宣告，違反讀作
     「與自身宣告不符」，無從辯解
  3. changed ⊆ writable_paths 且 ∩ forbidden = ∅（§3.3.1、§2.1）
  4. 受保護的測試基建未動（§3.2.3）：visible/regression tests、其祖先路徑的 conftest.py、
     pytest 設定、**永遠含 .github/**（worker 分支帶的 workflow 會在推到 fork 時執行）
  5. allow_new_dependencies=false 時 manifest 未動

V0 是**成本閘門**不是安全閘門（孿生 §3.2.3 實測：拿掉它 merged 不變、驗證成本 +14–24%）
——但它是唯一對所有驗證形式都 gating 的層，也是 §6.8.1 canary 最便宜的那一層。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable, Sequence

__all__ = ["V0Input", "V0Result", "check", "PROTECTED_ALWAYS", "DEPENDENCY_MANIFESTS",
           "matches_any"]

# 無條件受保護：任何交付都不得動到
PROTECTED_ALWAYS: tuple[str, ...] = (".github/**", ".sarment/**")
# §3.2.3 測試基建
_TEST_CONFIG = ("pytest.ini", "tox.ini", "setup.cfg", "pyproject.toml", "conftest.py")
# §6.1 V0「不引入新依賴」
DEPENDENCY_MANIFESTS: tuple[str, ...] = (
    "pyproject.toml", "requirements*.txt", "requirements/**", "setup.py", "setup.cfg",
    "Pipfile", "Pipfile.lock", "poetry.lock", "uv.lock", "package.json", "package-lock.json",
    "pnpm-lock.yaml", "yarn.lock", "go.mod", "go.sum", "Cargo.toml", "Cargo.lock",
)


def _glob_to_regex(g: str) -> "re.Pattern[str]":
    out = []
    i = 0
    while i < len(g):
        if g.startswith("**/", i):
            out.append("(?:.*/)?"); i += 3
        elif g.startswith("**", i):
            out.append(".*"); i += 2
        elif g[i] == "*":
            out.append("[^/]*"); i += 1
        elif g[i] == "?":
            out.append("[^/]"); i += 1
        else:
            out.append(re.escape(g[i])); i += 1
    return re.compile("^" + "".join(out) + "$")


def _norm(p: str) -> str:
    """去掉開頭的 `./` 與 `/`。⚠️ 不是 `lstrip("./")`——那會把 `.github/x` 剝成 `github/x`。"""
    while p.startswith("./"):
        p = p[2:]
    return p.lstrip("/")


def matches_any(path: str, globs: Iterable[str]) -> bool:
    """與 sarment.protocol.schemas.matches_any 同語意（verify 不依賴 sarment 套件，故複製）。"""
    p = _norm(path)
    for g in globs:
        g = _norm(g)
        if g.endswith("/"):
            g += "**"
        if g.endswith("/**") and p == g[:-3]:
            return True
        if _glob_to_regex(g).match(p):
            return True
    return False


@dataclass(frozen=True, slots=True)
class V0Input:
    changed_paths: tuple[str, ...]
    base_sha: str                         # 交付的 base
    snapshot_ref: str                     # WU 的快照
    declared_paths: tuple[str, ...]       # §5.2.6 commitment
    writable_paths: tuple[str, ...]       # §3.3.1
    forbidden_paths: tuple[str, ...] = ()
    visible_tests: tuple[str, ...] = ()
    regression_tests: tuple[str, ...] = ()
    allow_new_dependencies: bool = False


@dataclass(frozen=True, slots=True)
class V0Result:
    ok: bool
    reason: str = ""                      # 第一個失敗的規則（條號）
    offending: tuple[str, ...] = ()       # 觸發的路徑
    checks_run: tuple[str, ...] = ()      # §6.8.3：這次執行實際跑了哪些檢查

    @property
    def disclosable(self) -> str:
        """worker-ux §4.6：V0 完整揭露——它檢查的是 worker 自己看得到的東西。"""
        if self.ok:
            return "V0 pass"
        return f"V0 fail [{self.reason}]: {', '.join(self.offending)}"


def protected_paths(visible_tests: Sequence[str], regression_tests: Sequence[str]) -> tuple[str, ...]:
    """§3.2.3 的受保護集合：測試檔本身、其祖先目錄的 conftest.py、頂層 pytest 設定、.github。"""
    prot: list[str] = list(PROTECTED_ALWAYS)
    for t in (*visible_tests, *regression_tests):
        prot.append(t)
        parts = _norm(t).split("/")[:-1]
        for i in range(len(parts) + 1):
            prefix = "/".join(parts[:i])
            prot.append(f"{prefix}/conftest.py" if prefix else "conftest.py")
    prot.extend(_TEST_CONFIG)
    return tuple(dict.fromkeys(prot))


def check(inp: V0Input) -> V0Result:
    run: list[str] = []
    changed = tuple(_norm(p) for p in inp.changed_paths)

    run.append("§3.1 base==snapshot")
    if not inp.base_sha or not inp.snapshot_ref.startswith(inp.base_sha[:7]) \
            and not inp.base_sha.startswith(inp.snapshot_ref[:7]):
        return V0Result(False, "§3.1 stale base", (inp.base_sha,), tuple(run))

    run.append("§5.2.6.1 ⊆ declared")
    bad = tuple(p for p in changed if not matches_any(p, inp.declared_paths))
    if bad:
        return V0Result(False, "§5.2.6.1 outside own commitment", bad, tuple(run))

    run.append("§3.3.1 ⊆ writable ∧ ∉ forbidden")
    bad = tuple(p for p in changed
                if matches_any(p, inp.forbidden_paths) or not matches_any(p, inp.writable_paths))
    if bad:
        return V0Result(False, "§3.3.1 outside writable_paths", bad, tuple(run))

    run.append("§3.2.3 tests untouched")
    prot = protected_paths(inp.visible_tests, inp.regression_tests)
    bad = tuple(p for p in changed if matches_any(p, prot))
    if bad:
        return V0Result(False, "§3.2.3 protected test infrastructure modified", bad, tuple(run))

    if not inp.allow_new_dependencies:
        run.append("§6.1 no new dependencies")
        bad = tuple(p for p in changed if matches_any(p, DEPENDENCY_MANIFESTS))
        if bad:
            return V0Result(False, "§6.1 dependency manifest modified", bad, tuple(run))

    return V0Result(True, checks_run=tuple(run))
