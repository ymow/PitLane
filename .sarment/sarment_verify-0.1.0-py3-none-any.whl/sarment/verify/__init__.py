"""Sarment 驗證核心（SPEC §10.3.2 的「驗證 harness」）。

與 worker harness 分離、獨立版本、簽章發佈：worker 端的 V0/V1 預檢與 coordinator
端跑的是**同一份**程式碼（`core_version` 隨 WU header 下發）。

僅 stdlib。任何第三方依賴都會讓「簽章驗過的 wheel 就是全部」這個承諾失效。
M2：v0_diff。M3：testrun / ladder / text。attestation 的簽章需要 ed25519，放 coordinator（M4）。
"""

from . import ladder, testrun, text, v0_diff  # noqa: F401

CORE_VERSION = "0.1.0"

__all__ = ["CORE_VERSION", "v0_diff", "testrun", "ladder", "text"]
