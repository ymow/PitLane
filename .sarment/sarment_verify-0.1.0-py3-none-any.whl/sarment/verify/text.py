"""SPEC §10.2.2：coordinator 出站的所有文字 MUST 掃隱形 Unicode／bidi／零寬字元。

harness 寫 WU.md 前也用同一個函式（§10.2：Charter／issue 文字是不可信資料）。
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass

__all__ = ["scan_invisible", "InvisibleHit", "sanitize"]

# 明確列舉的高風險字元：零寬、bidi 覆寫、軟連字、BOM、標籤字元
_EXPLICIT = {
    "​": "ZERO WIDTH SPACE", "‌": "ZWNJ", "‍": "ZWJ", "⁠": "WORD JOINER",
    "﻿": "BOM/ZWNBSP", "­": "SOFT HYPHEN",
    "‪": "LRE", "‫": "RLE", "‬": "PDF", "‭": "LRO", "‮": "RLO",
    "⁦": "LRI", "⁧": "RLI", "⁨": "FSI", "⁩": "PDI",
    "‎": "LRM", "‏": "RLM", "؜": "ALM",
}


@dataclass(frozen=True, slots=True)
class InvisibleHit:
    offset: int
    codepoint: str
    name: str


def scan_invisible(text: str) -> list[InvisibleHit]:
    hits = []
    for i, ch in enumerate(text):
        if ch in _EXPLICIT:
            hits.append(InvisibleHit(i, f"U+{ord(ch):04X}", _EXPLICIT[ch]))
            continue
        if 0xE0000 <= ord(ch) <= 0xE007F:                   # TAG 字元（ASCII smuggling）
            hits.append(InvisibleHit(i, f"U+{ord(ch):04X}", "TAG"))
            continue
        cat = unicodedata.category(ch)
        # Cf = format（多數隱形）、Co = private use；Cc 控制字元但放過常見空白
        if cat in ("Cf", "Co") or (cat == "Cc" and ch not in "\n\r\t"):
            hits.append(InvisibleHit(i, f"U+{ord(ch):04X}", unicodedata.name(ch, cat)))
    return hits


def sanitize(text: str) -> tuple[str, list[InvisibleHit]]:
    """移除命中的字元，回傳 (乾淨文字, 命中清單)。命中數 MUST 顯示給 worker（worker-ux §5）。"""
    hits = scan_invisible(text)
    if not hits:
        return text, []
    bad = {h.offset for h in hits}
    return "".join(ch for i, ch in enumerate(text) if i not in bad), hits
