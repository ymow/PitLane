"""跑 pytest 並把結果變成結構化資料（SPEC §6.1 V1/V2/V3 的執行單元）。

搬自 spike/f2p/harness.py `run_pytest`，差別：
- 不做沙箱——隔離是 CI backend 的責任（§6.2.2）。這個函式在 backend **裡面**被呼叫
  （docker 容器內或 subprocess），所以自己只管「怎麼跑、怎麼讀結果」。
- 回傳 `TestRun`，含 pytest 的 rc 語意：0 全過、1 有失敗、2 中斷、3 內部錯誤、4 用法錯、
  5 沒收到測試。V2 的 crash oracle 靠這個區分「測試紅」與「程序死了」。

`python -m sarment.verify.testrun --json <tests...>` 是容器內的進入點：印一行 JSON。
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

__all__ = ["TestRun", "run_pytest", "CRASH_MARKERS", "main"]

CRASH_MARKERS = ("Fatal Python error", "Segmentation fault", "Aborted", "core dumped",
                 "MemoryError", "INTERNALERROR")
_SUMMARY = re.compile(r"(\d+) passed|(\d+) failed|(\d+) error", re.I)


@dataclass(frozen=True, slots=True)
class TestRun:
    rc: int                         # pytest 回傳碼；-9 = timeout；< 0 = 訊號
    passed: int
    failed: int
    errors: int
    seconds: float
    crashed: bool                   # 程序非正常終止（訊號／timeout／內部錯誤／crash 標記）
    stdout_tail: str                # 最後 4000 字元；V3 的這段**不得**離開 coordinator
    tests: tuple[str, ...]

    @property
    def all_passed(self) -> bool:
        return self.rc == 0 and not self.crashed

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, s: str) -> "TestRun":
        d = json.loads(s)
        d["tests"] = tuple(d["tests"])
        return cls(**d)


def _counts(out: str) -> tuple[int, int, int]:
    p = f = e = 0
    for m in _SUMMARY.finditer(out):
        if m.group(1):
            p = int(m.group(1))
        if m.group(2):
            f = int(m.group(2))
        if m.group(3):
            e = int(m.group(3))
    return p, f, e


def run_pytest(checkout: Path, tests: Sequence[str], *, python: str = sys.executable,
               timeout_s: float = 600.0, crash_oracle: bool = False,
               env: dict[str, str] | None = None, pythonpath: Sequence[str] = (),
               workdir: str | None = None) -> TestRun:
    """在 `checkout` 裡跑 pytest。`crash_oracle=True` 加 `-X faulthandler -X dev`（V2）。
    `workdir`：相對 checkout 的子目錄，pytest 從那裡啟動（rootdir／ini 在子目錄的 repo，例如 Django 的 backend/）；
    tests 仍相對 checkout 根給，這裡轉成相對 workdir。"""
    cwd = checkout / workdir if workdir else checkout
    if workdir:
        tests = [os.path.relpath(str(checkout / t), str(cwd)) for t in tests]
    args = [python]
    if crash_oracle:
        # V2 sanitizer：dev mode + warnings→error + faulthandler。測試紅不算 crash，
        # 但 import 期的 DeprecationWarning／ResourceWarning 會讓收集炸掉（rc 2）——
        # 那是「在正常模式下看不見的髒東西」，正是這一層要抓的。
        args += ["-X", "faulthandler", "-X", "dev", "-W", "error"]
    args += ["-m", "pytest", "-q", "--no-header", "-p", "no:cacheprovider", "-x" if crash_oracle else "-rN",
             *tests]
    e = dict(env) if env is not None else {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": str(checkout),
        "LANG": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1"}
    e.setdefault("PYTHONPATH", os.pathsep.join([str(cwd), str(checkout), *(str(checkout / x) for x in pythonpath)]))
    if crash_oracle:
        e["PYTHONMALLOC"] = "debug"
    t0 = time.monotonic()
    try:
        r = subprocess.run(args, cwd=str(cwd), env=e, capture_output=True, text=True,
                           timeout=timeout_s)
        rc, out = r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired as ex:
        rc, out = -9, ((ex.stdout or b"").decode(errors="replace") if isinstance(ex.stdout, bytes) else (ex.stdout or "")) + "\n[timeout]"
    secs = time.monotonic() - t0
    p, f, er = _counts(out)
    crashed = rc < 0 or rc >= 3 or any(m in out for m in CRASH_MARKERS)
    return TestRun(rc=rc, passed=p, failed=f, errors=er, seconds=round(secs, 3), crashed=crashed,
                   stdout_tail=out[-4000:], tests=tuple(tests))


def main(argv: list[str] | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("tests", nargs="+")
    ap.add_argument("--checkout", default=".")
    ap.add_argument("--timeout", type=float, default=600.0)
    ap.add_argument("--crash-oracle", action="store_true")
    ap.add_argument("--pythonpath", action="append", default=[])
    ap.add_argument("--workdir", default=None)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    r = run_pytest(Path(a.checkout).resolve(), a.tests, timeout_s=a.timeout, crash_oracle=a.crash_oracle,
                   pythonpath=a.pythonpath, workdir=a.workdir)
    print(r.to_json() if a.json else f"rc={r.rc} passed={r.passed} failed={r.failed} crashed={r.crashed}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
