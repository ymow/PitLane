"""SPEC §6.1 驗證階梯：依成本梯度執行、第一個 gating 失敗即短路、§6.1.3 不確定性層先重跑。

搬自 twin/sarment_twin/verification.py 的結構，差別：
- 每層的「檢查」是一個 callable，回傳 (ok, minutes, detail)——怎麼跑（docker、Actions、
  純函式）是 coordinator 的 backend 的事，這裡只管順序、gating、重跑、flake 歸因。
- flake 的定義是**可觀測的**：同一層第一次 FAIL、重跑 PASS。不需要 ground truth。
- 非 gating 的失敗**結構上**到不了 REJECT：唯一通往 REJECT 的路徑是 `outcome is FAIL and gating`。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable

__all__ = ["Outcome", "Action", "LayerSpec", "LayerRun", "LadderResult", "run_ladder"]


class Outcome(Enum):
    PASS = "pass"
    FAIL = "fail"
    WARN = "warn"
    FLAG = "flag"
    RANK = "rank"
    SKIP = "skip"


class Action(Enum):
    REJECT = "reject"
    RETURN_FOR_FIX = "return_for_fix"
    WARN_ONLY = "warn_only"
    FLAG_ONLY = "flag_only"
    RANK_ONLY = "rank_only"


# check() -> (ok, minutes, detail, run_ref)
Check = Callable[[], tuple[bool, float, str, str]]


@dataclass(frozen=True, slots=True)
class LayerSpec:
    name: str                       # "V0".."V7"
    gating: bool
    on_fail: Action
    check: Check | None             # None = 這一層本次沒有 backend → SKIP（不是 PASS，§6.8.3）
    nondeterministic: bool = False  # 測試執行會 flake；純函式不會
    backend: str = ""


@dataclass(frozen=True, slots=True)
class LayerRun:
    name: str
    outcome: Outcome
    gating: bool
    attempts: int
    minutes: float
    detail: str
    backend: str
    run_ref: str = ""


@dataclass(frozen=True, slots=True)
class LadderResult:
    layers: tuple[LayerRun, ...]
    decision: str                   # "reject" | "return_for_fix" | "await"（全 gating 通過）
    first_failing: str | None
    flaked: str | None              # 第一次 FAIL、重跑 PASS 的層（可觀測 flake）
    minutes: float


def run_ladder(specs: tuple[LayerSpec, ...], *, retries: int = 1,
               rerun_budget_left: int = 0) -> LadderResult:
    runs: list[LayerRun] = []
    flaked: str | None = None
    total = 0.0
    for L in specs:
        if L.check is None:
            runs.append(LayerRun(L.name, Outcome.SKIP, L.gating, 0, 0.0, "no backend", L.backend))
            continue
        ok, mins, detail, ref = L.check()
        attempts = 1
        total += mins
        left = retries if L.nondeterministic else 0
        while not ok and left > 0:                          # §6.1.3
            left -= 1
            ok2, m2, d2, ref = L.check()
            attempts += 1
            total += m2
            if ok2:
                ok, detail = True, f"{detail} → rerun passed (flake)"
                if flaked is None:
                    flaked = L.name
            else:
                detail = d2
        if ok:
            runs.append(LayerRun(L.name, Outcome.PASS, L.gating, attempts, mins, detail, L.backend, ref))
            continue
        if not L.gating:
            mark = {Action.WARN_ONLY: Outcome.WARN, Action.FLAG_ONLY: Outcome.FLAG,
                    Action.RANK_ONLY: Outcome.RANK}[L.on_fail]
            runs.append(LayerRun(L.name, mark, False, attempts, mins, detail, L.backend, ref))
            continue
        runs.append(LayerRun(L.name, Outcome.FAIL, True, attempts, mins, detail, L.backend, ref))
        decision = ("return_for_fix"
                    if L.on_fail is Action.RETURN_FOR_FIX and rerun_budget_left > 0 else "reject")
        return LadderResult(tuple(runs), decision, L.name, flaked, round(total, 4))
    return LadderResult(tuple(runs), "await", None, flaked, round(total, 4))
